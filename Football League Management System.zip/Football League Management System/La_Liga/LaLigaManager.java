package La_Liga;
import java.util.*;
import League_Launcher_Main.LeagueLauncher;

public class LaLigaManager extends LaLiga{
  
    private final ArrayList<LaLiga> llLeague = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
	
	public void laLiga(){
		LeagueLauncher leagueLauncher = new LeagueLauncher();
		while(true){
			System.out.println();
			System.out.println("***************La Liga*******************");
			System.out.println("1. Start League");
			System.out.println("2. Add Team to League");
			System.out.println("3. Delete Team from League");
			System.out.println("4. Enter Match Details");
			System.out.println("5. Show League Table");
			System.out.println("6. End League");
			System.out.println("7. Choose another League");
			System.out.println("8. End Program");
			System.out.println();
			System.out.print("Enter Choice: ");
			int choice = 0;
			try{
				choice = sc.nextInt();
			}catch(InputMismatchException e){
				System.out.println("Enter valid Number");
				System.exit(0);
			}
			
			switch(choice){
				case 1 : 
						startLeague();
						break;
				case 2 : 
						addTeam();
						break;
				case 3 : 
						deleteTeam();
						break;
				case 4 : 
						matchDetails();
						break;
				case 5 : 
						leagueTable();
						break;
				case 6 : endLeague();
						break;
				case 7 : leagueLauncher.selectLeagueMenu();
						break;
				case 8 : System.exit(0);
						break;
				default : System.out.println("Invalid Choice"); 
						break;
				
			}
		}
	}
	
	public void startLeague(){
		
		for(LaLiga club : llLeague){
			club.setWinCount(0);
			club.setDrawCount(0);
			club.setDefeatCount(0);
			club.setScoredGoalsCount(0);
			club.setPoints(0);
			club.setMatchesPlayed(0);

		}
	}
	
	public void addTeam(){
        LaLiga club = new LaLigaManager();
        System.out.println("Insert Club Name: ");
		Scanner sc = new Scanner(System.in);
        String newteamName = sc.nextLine();
        club.setclubName(newteamName);
        if(llLeague.contains(club)){
            System.out.println("This club is already in the Premier League");
            return;
        }
        System.out.println("C");
        llLeague.add(club);  
		System.out.println("Team "+newteamName+" added successfully");
    }
	
	public void deleteTeam() {
        System.out.println("Insert club name: ");
		Scanner sc = new Scanner(System.in);
        String deleteTeamName = sc.nextLine();
         for(LaLiga club : llLeague) {
             if(club.getclubName().equals(deleteTeamName)){
                 llLeague.remove(club);
                 System.out.println("Club "+ club.getclubName()+" removed");
                 return;
             }
         }
         System.out.println("No such club in La Liga");
    }	
	public void matchDetails(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Team 1 Name ");
		String team1Name = sc.nextLine();
		LaLiga team1 = null;
          for(LaLiga club : llLeague){
              if(club.getclubName().equals(team1Name))
                  team1 = club;
          }  
          if (team1 == null) {
              System.out.println("This club does not exist in the La Liga");
              return;
          }
        
		System.out.println("Enter Team 2 Name ");
		String team2Name = sc.nextLine();
		
		LaLiga team2 = null;
          for(LaLiga club : llLeague){
              if(club.getclubName().equals(team2Name))
                  team2 = club;
          }  
          if (team2 == null) {
              System.out.println("This club does not exist in the llLeague");
              return;
          }
		  
		System.out.println("Enter "+team1.getclubName()+" team goals");
		int team1goals = sc.nextInt();
		System.out.println("Enter "+team2.getclubName()+" team goals");
		int team2goals = sc.nextInt();
		
		if(team1goals>team2goals){
			team1.setWinCount(team1.getWinCount()+1);
			team1.setPoints(team1.getPoints()+3);
			team1.setScoredGoalsCount(team1.getScoredGoalsCount()+team1goals);
			team1.setMatchesPlayed(team1.getMatchesPlayed()+1);
			team2.setMatchesPlayed(team2.getMatchesPlayed()+1);
			team2.setDefeatCount(team2.getDefeatCount()+1);
		}
		else if(team2goals>team1goals){
			team2.setWinCount(team2.getWinCount()+1);
			team2.setPoints(team2.getPoints()+3);
			team2.setScoredGoalsCount(team2.getScoredGoalsCount()+team2goals);
			team1.setMatchesPlayed(team1.getMatchesPlayed()+1);
			team2.setMatchesPlayed(team2.getMatchesPlayed()+1);
			team1.setDefeatCount(team1.getDefeatCount()+1);
		}else{
			team1.setDrawCount(team1.getDrawCount()+1);
			team2.setDrawCount(team2.getDrawCount()+1);
			team1.setPoints(team1.getPoints()+1);
			team2.setPoints(team2.getPoints()+1);
			team1.setMatchesPlayed(team1.getMatchesPlayed()+1);
			team2.setMatchesPlayed(team2.getMatchesPlayed()+1);
			team1.setScoredGoalsCount(team1.getScoredGoalsCount()+team1goals);
			team2.setScoredGoalsCount(team2.getScoredGoalsCount()+team2goals);
		}
	}
	
	public void sort(){
		Comparator<LaLiga> compareById = 
		(LaLiga o1, LaLiga o2) -> String.valueOf(o1.getPoints()).compareTo( String.valueOf(o2.getPoints()) );

		Collections.sort(llLeague, compareById.reversed()); // Descending Order
    }
	
	public void leagueTable(){
		sort();
		String title = String.format("%-10s %-10s %-10s %-10s %-20s %-20s %-10s","Club Name","Wins","Losses","Draws","Matches Played","Total Goals","Points");
		System.out.println(title);
		for(LaLiga club : llLeague){
			String strTable = String.format("%-10s %-10d %-10d %-10d %-20d %-20d %-10d", club.getclubName(),club.getWinCount(),club.getDefeatCount(),club.getDrawCount(),club.getMatchesPlayed(),club.getScoredGoalsCount(),club.getPoints());
			System.out.println(strTable);  	
          } 
	}
	
	public void endLeague(){
		sort();
		leagueTable();
		System.out.println();
		System.out.println(llLeague.get(0).getclubName()+" is winner of the Premier League");
		startLeague();
	}
	
	
	}
