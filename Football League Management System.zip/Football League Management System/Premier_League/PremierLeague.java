package Premier_League;
import League_Manager.LeagueManager;

abstract public class PremierLeague implements LeagueManager{
	private String clubName;
    private int winCount;
    private int drawCount;
    private int defeatCount;
    private int scoredGoalsCount;
    private int points;
    private int matchesPlayed;
    
	public String getclubName(){
		return clubName;
	}
	
    public int getWinCount(){
        return winCount;
    }
    
    public int getDrawCount() {
        return drawCount;
    }
    
    public int getDefeatCount(){
        return defeatCount;
    }
    
    public int getScoredGoalsCount() {
        return scoredGoalsCount;
    }
    
    public int getPoints() {
        return points;
    }
    
    public int getMatchesPlayed() {
        return matchesPlayed;
    }
	public void setclubName(String clubName){
		this.clubName = clubName;
	}
    
    public void setWinCount(int winCount) {
        this.winCount = winCount;
    }
    
    public void setDrawCount(int drawCount){
        this.drawCount = drawCount;
    }
    
    public void setDefeatCount(int defeatCount) {
        this.defeatCount = defeatCount;
    }
    
    public void setScoredGoalsCount(int scoredGoalsCount){
        this.scoredGoalsCount = scoredGoalsCount;
    }
     
    public void setPoints(int scoredGoalsCount){
        this.points = scoredGoalsCount;
    }
    
    public void setMatchesPlayed(int matchesPlayed){
        this.matchesPlayed = matchesPlayed;
    }
	@Override
	public boolean equals(Object o){
		if(o instanceof PremierLeague){ 
			PremierLeague temp = (PremierLeague)o; 
			
			if(this.clubName.equals(temp.clubName)
				){
				return true;
			}
		}
		return false;
	}
    
}
