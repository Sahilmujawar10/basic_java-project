package League_Manager;

public interface LeagueManager{
	public abstract void startLeague();
	public abstract void addTeam();
	public abstract void deleteTeam();
	public abstract void matchDetails();
	public abstract void sort();
	public abstract void leagueTable();
	public abstract void endLeague();
}