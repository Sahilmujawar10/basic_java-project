package League_Launcher_Main;
import java.util.*;
import Premier_League.PremierLeague;
import Premier_League.PremierLeagueManager;
import La_Liga.LaLiga;
import La_Liga.LaLigaManager;
//import League_Manager.LeagueManager;

public class LeagueLauncher{
	static PremierLeagueManager prLauncher = null;
	static LaLigaManager llLauncher = null;
	Scanner sc = new Scanner(System.in);
	public void selectLeagueMenu(){
		if(prLauncher == null ){
			prLauncher = new PremierLeagueManager();
		}
		if(llLauncher == null ){
			llLauncher = new LaLigaManager();
		}
		System.out.println();
		System.out.println("Select League");
		System.out.println("1. Premier League");
		System.out.println("2. La Liga");
		System.out.println();
		System.out.print("Enter Choice: ");
		int choice = 0;
		try{
			choice = sc.nextInt();
		}catch(InputMismatchException e){
			System.out.println("Enter valid Number");
			System.exit(0);
		}
		switch(choice){
			case 1 	:prLauncher.premierLeague();
					break;
			case 2 	:llLauncher.laLiga();
					break;
			default :System.out.println("Invalid League"); 
					break;
			
		}
	}
	
	public static void main(String[] args){
		LeagueLauncher leagueLauncher = new LeagueLauncher();
		leagueLauncher.selectLeagueMenu();
		
	}
}